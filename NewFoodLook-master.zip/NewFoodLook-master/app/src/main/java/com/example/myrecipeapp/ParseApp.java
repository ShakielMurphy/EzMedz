package com.example.myrecipeapp;

import android.app.Application;

import com.parse.Parse;
import com.parse.ParseObject;

public class ParseApp extends Application {

        @Override
        public void onCreate() {
            super.onCreate();

            // Register your parse models
            ParseObject.registerSubclass(Post.class);

            Parse.initialize(new Parse.Configuration.Builder(this)
                    .applicationId("DxwcCstX2BsmA3BtFcXN0wLYIQ67vzHI1rzYi3qm")
                    .clientKey("q92pzNXNiF9dijIX4xH5w26bcroAX09f13W01d9H")
                    .server("https://parseapi.back4app.com")
                    .build()
            );
        }
}
